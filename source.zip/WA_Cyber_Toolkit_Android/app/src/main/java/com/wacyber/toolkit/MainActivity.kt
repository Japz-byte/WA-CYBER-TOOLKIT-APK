package com.wacyber.toolkit

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.*
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.*
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import java.net.HttpURLConnection
import java.net.InetAddress
import java.net.URL
import java.security.SecureRandom
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.roundToInt

class MainActivity : Activity() {
    private val bg = 0xFF050907.toInt()
    private val panel = 0xFF0B1710.toInt()
    private val green = 0xFF39FF88.toInt()
    private val muted = 0xFF9AB6A4.toInt()
    private val red = 0xFFFF647C.toInt()
    private lateinit var root: LinearLayout
    private lateinit var output: TextView
    private val executor = Executors.newSingleThreadExecutor()
    private val chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789!@#$%&*+-_"
    private val riskyExtensions = setOf("apk", "exe", "bat", "cmd", "com", "scr", "js", "vbs", "ps1", "jar", "msi", "sh")
    private val locationRequestCode = 110
    private val fileRequestCode = 120
    private var locationListener: LocationListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        showHome()
    }

    private fun buildUi() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(18), dp(12), dp(18), dp(18))
        }
        val scroll = ScrollView(this)
        val inner = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val header = TextView(this).apply {
            text = "▰ WA CYBER TOOLKIT\n// ANDROID FIELD CONSOLE"
            textSize = 21f
            setTextColor(green)
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, dp(18))
        }
        inner.addView(header)
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("HOME", "TOOLS", "MONITOR").forEach { label ->
            nav.addView(Button(this).apply {
                text = label
                setTextColor(green)
                setBackgroundColor(panel)
                setOnClickListener {
                    when (label) {
                        "HOME" -> showHome()
                        "TOOLS" -> showTools()
                        else -> showMonitor()
                    }
                }
            }, LinearLayout.LayoutParams(0, dp(46), 1f).apply { setMargins(dp(3), 0, dp(3), dp(12)) })
        }
        inner.addView(nav)
        output = TextView(this).apply {
            textSize = 13f
            setTextColor(muted)
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(panel)
        }
        inner.addView(output, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 0, 0, dp(12)) })
        scroll.addView(inner)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun showHome() {
        clearActions()
        output.text = """
            STATUS: READY
            ━━━━━━━━━━━━━━━━━━━━━
            PILIH MODUL DI BAWAH

            • WhatsApp Launcher
            • GPS perangkat
            • File Scanner
            • Device Monitor
            • Network Diagnostics
            • Password Generator

            Semua pemeriksaan dijalankan di perangkat.
            GPS membutuhkan izin lokasi. Pemeriksaan jaringan
            membutuhkan koneksi internet.
        """.trimIndent()
        addAction("WHATSAPP LAUNCHER") { showWhatsApp() }
        addAction("GPS PERANGKAT") { getLocation() }
        addAction("FILE SCANNER") { chooseFile() }
        addAction("DEVICE MONITOR") { showMonitor() }
        addAction("NETWORK DIAGNOSTICS") { networkDiagnostics() }
        addAction("PASSWORD GENERATOR") { passwordGenerator() }
    }

    private fun showTools() {
        clearActions()
        output.text = "TOOLS // pilih modul\n\nLauncher membuka chat WhatsApp melalui tautan resmi. File Scanner memeriksa metadata file yang kamu pilih."
        addAction("WHATSAPP LAUNCHER") { showWhatsApp() }
        addAction("FILE SCANNER") { chooseFile() }
        addAction("NETWORK DIAGNOSTICS") { networkDiagnostics() }
        addAction("PASSWORD GENERATOR") { passwordGenerator() }
    }

    private fun showMonitor() {
        clearActions()
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork
        val caps = if (network != null) cm.getNetworkCapabilities(network) else null
        val connection = when {
            caps == null -> "OFFLINE"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Data seluler"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            else -> "Terhubung"
        }
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        windowManager.defaultDisplay.getRealMetrics(dm)
        val am = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        val mem = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mem)
        val battery = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = battery?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = battery?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        val pct = if (level >= 0 && scale > 0) (level * 100f / scale).roundToInt().toString() + "%" else "Tidak tersedia"
        output.text = """
            DEVICE MONITOR
            ━━━━━━━━━━━━━━━━━━━━━
            Model       : ${Build.MANUFACTURER} ${Build.MODEL}
            Android     : ${Build.VERSION.RELEASE} (SDK ${Build.VERSION.SDK_INT})
            Perangkat   : ${Build.DEVICE}
            Resolusi    : ${dm.widthPixels} × ${dm.heightPixels}
            Bahasa      : ${Locale.getDefault().toLanguageTag()}
            Baterai     : $pct
            RAM bebas   : ${mem.availMem / (1024 * 1024)} MB
            Koneksi     : $connection
            Waktu       : ${SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())}
        """.trimIndent()
        addAction("UJI JARINGAN") { networkDiagnostics() }
        addAction("KEMBALI KE HOME") { showHome() }
    }

    private fun showWhatsApp() {
        clearActions()
        val box = EditText(this).apply {
            hint = "Nomor, contoh 628123456789"
            setHintTextColor(muted)
            setTextColor(green)
            setSingleLine(true)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(panel)
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        val message = EditText(this).apply {
            hint = "Pesan awal (opsional)"
            setHintTextColor(muted)
            setTextColor(green)
            setPadding(dp(12), dp(10), dp(12), dp(10))
            setBackgroundColor(panel)
        }
        output.text = "WHATSAPP LAUNCHER\nMasukkan nomor dengan kode negara, tanpa tanda + atau spasi."
        addView(box)
        addView(message)
        addAction("BUKA CHAT WHATSAPP") {
            val number = box.text.toString().filter { it.isDigit() }
            if (number.length !in 8..15) {
                toast("Periksa nomor dan kode negaranya")
            } else {
                val uri = android.net.Uri.parse("https://wa.me/$number")
                val intent = Intent(Intent.ACTION_VIEW, uri)
                try {
                    startActivity(intent)
                } catch (_: Exception) {
                    toast("Browser tidak dapat membuka tautan")
                }
            }
        }
        addAction("SALIN NOMOR") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("Nomor", box.text.toString()))
            toast("Nomor disalin")
        }
    }

    private fun getLocation() {
        if (Build.VERSION.SDK_INT >= 23 &&
            checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
            checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), locationRequestCode)
            output.text = "GPS PERANGKAT\nIzinkan akses lokasi untuk membaca koordinat perangkat ini."
            return
        }
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val providers = lm.getProviders(true)
            var best: Location? = null
            for (p in providers) {
                @Suppress("MissingPermission")
                val loc = lm.getLastKnownLocation(p)
                if (loc != null && (best == null || loc.accuracy < best.accuracy)) best = loc
            }
            if (best != null) {
                displayLocation(best)
            } else {
                output.text = "GPS PERANGKAT\nBelum ada koordinat terakhir. Aktifkan layanan lokasi dan coba lagi."
                val provider = when {
                    lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                    lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                    else -> null
                }
                if (provider != null) {
                    val listener = object : LocationListener {
                        override fun onLocationChanged(location: Location) {
                            displayLocation(location)
                            try { lm.removeUpdates(this) } catch (_: Exception) {}
                        }
                    }
                    locationListener = listener
                    @Suppress("MissingPermission")
                    lm.requestLocationUpdates(provider, 1000L, 0f, listener)
                    toast("Mencari koordinat perangkat…")
                }
            }
        } catch (e: Exception) {
            output.text = "GPS ERROR\n${e.localizedMessage ?: "Tidak dapat membaca lokasi"}"
        }
        addAction("BUKA PETA") {
            val text = output.text.toString()
            val regex = Regex("LAT: (-?[0-9.]+)\\s+LON: (-?[0-9.]+)")
            val m = regex.find(text)
            if (m != null) startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("geo:${m.groupValues[1]},${m.groupValues[2]}?q=${m.groupValues[1]},${m.groupValues[2]}")))
            else toast("Ambil lokasi terlebih dahulu")
        }
    }

    private fun displayLocation(loc: Location) {
        runOnUiThread {
            output.text = "GPS PERANGKAT\n━━━━━━━━━━━━━━━━━━━━━\nLAT: ${loc.latitude}\nLON: ${loc.longitude}\nAkurasi: ±${loc.accuracy.roundToInt()} meter\nSumber: ${loc.provider ?: "Perangkat"}\n\nKoordinat hanya dibaca setelah izin lokasi diberikan."
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == locationRequestCode) {
            if (grantResults.any { it == PackageManager.PERMISSION_GRANTED }) getLocation()
            else toast("Izin lokasi tidak diberikan")
        }
    }

    private fun chooseFile() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, fileRequestCode)
    }

    @Deprecated("Uses document picker for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != fileRequestCode || resultCode != Activity.RESULT_OK) return
        val uri = data?.data ?: return
        try {
            var name = "File tidak dikenal"
            var size = -1L
            contentResolver.query(uri, null, null, null, null)?.use { cursor ->
                if (cursor.moveToFirst()) {
                    val ni = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    val si = cursor.getColumnIndex(OpenableColumns.SIZE)
                    if (ni >= 0) name = cursor.getString(ni) ?: name
                    if (si >= 0 && !cursor.isNull(si)) size = cursor.getLong(si)
                }
            }
            val ext = name.substringAfterLast('.', "").lowercase(Locale.ROOT)
            val warning = if (ext in riskyExtensions) "PERLU DITINJAU: ekstensi file dapat menjalankan kode." else "Tidak ada ekstensi yang masuk daftar pemeriksaan dasar."
            output.text = """
                FILE SCANNER
                ━━━━━━━━━━━━━━━━━━━━━
                Nama      : $name
                Ekstensi  : ${if (ext.isBlank()) "(tanpa ekstensi)" else ext}
                Ukuran    : ${if (size >= 0) "$size byte" else "Tidak tersedia"}
                Tipe MIME : ${contentResolver.getType(uri) ?: "Tidak tersedia"}

                HASIL PEMERIKSAAN
                $warning

                Pemeriksaan ini membaca metadata dan ekstensi; bukan analisis antivirus penuh.
            """.trimIndent()
        } catch (e: Exception) {
            output.text = "FILE SCANNER\nTidak dapat membaca metadata: ${e.localizedMessage}"
        }
    }

    private fun networkDiagnostics() {
        output.text = "NETWORK DIAGNOSTICS\nMenjalankan pemeriksaan koneksi dan waktu respons…"
        executor.execute {
            val start = System.currentTimeMillis()
            var dns = "GAGAL"
            var http = "Tidak diuji"
            var code = -1
            var error = ""
            try {
                val ip = InetAddress.getByName("example.com")
                dns = ip.hostAddress ?: "OK"
            } catch (e: Exception) { error = e.javaClass.simpleName }
            var elapsed = -1L
            try {
                val conn = (URL("https://www.google.com/generate_204").openConnection() as HttpURLConnection)
                conn.connectTimeout = 5000
                conn.readTimeout = 5000
                conn.requestMethod = "GET"
                val t = System.currentTimeMillis()
                code = conn.responseCode
                elapsed = System.currentTimeMillis() - t
                conn.disconnect()
                http = "$code (${elapsed} ms)"
            } catch (e: Exception) { error = e.javaClass.simpleName }
            val total = System.currentTimeMillis() - start
            runOnUiThread {
                output.text = """
                    NETWORK DIAGNOSTICS
                    ━━━━━━━━━━━━━━━━━━━━━
                    DNS example.com : $dns
                    HTTPS response : $http
                    Total duration : ${total} ms
                    Error           : ${if (error.isBlank()) "Tidak ada" else error}

                    Kode 204 biasanya berarti endpoint uji merespons tanpa isi. Hasil dipengaruhi jaringan dan kebijakan browser/perangkat.
                """.trimIndent()
            }
        }
    }

    private fun passwordGenerator() {
        val password = (1..20).map { chars[SecureRandom().nextInt(chars.length)] }.joinToString("")
        val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("Password", password))
        output.text = "PASSWORD GENERATOR\n━━━━━━━━━━━━━━━━━━━━━\n$password\n\nPanjang: 20 karakter\nPassword telah disalin ke clipboard.\nSimpan di pengelola password pilihanmu."
        addAction("BUAT PASSWORD BARU") { passwordGenerator() }
    }

    private fun addAction(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = "›  $label"
            textSize = 13f
            setTextColor(green)
            setBackgroundColor(panel)
            isAllCaps = false
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), 0, dp(16), 0)
            setOnClickListener {
                clearActions()
                action()
            }
        }
        actions.add(b)
        root.addView(b, 0, LinearLayout.LayoutParams(-1, dp(48)).apply { setMargins(dp(18), dp(3), dp(18), dp(3)) })
    }

    private val actions = mutableListOf<View>()
    private val dynamicViews = mutableListOf<View>()

    private fun addView(view: View) {
        dynamicViews.add(view)
        root.addView(view, 0, LinearLayout.LayoutParams(-1, dp(48)).apply { setMargins(dp(18), dp(4), dp(18), dp(4)) })
    }

    private fun clearActions() {
        actions.forEach { root.removeView(it) }
        actions.clear()
        dynamicViews.forEach { root.removeView(it) }
        dynamicViews.clear()
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        super.onDestroy()
        executor.shutdownNow()
        try { locationListener?.let { (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(it) } } catch (_: Exception) {}
    }
}
